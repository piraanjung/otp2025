<?php

namespace App\Http\Controllers\KeptKaya;

use App\Exports\PriceTemplateExport;
use App\Http\Controllers\Controller;
use App\Imports\KpTbankPriceImport;
use App\Models\Admin\Organization;
use App\Models\KeptKaya\KpTbankItems;
use App\Models\KeptKaya\KpTbankItemsPriceAndPoint;
use App\Models\KeptKaya\KpTbankUnits;
use App\Models\Admin\Staff;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class KpTbankPriceController extends Controller
{
    /**
     * Display a listing of prices.
     */
    public function index()
    {
        $prices = KpTbankItemsPriceAndPoint::with(['item', 'kp_units_info'])
            ->where('org_id_fk', Auth::user()->org_id_fk)
            ->where('status', 'active')
            ->orderByDesc('effective_date')
            ->paginate(20);
        return view('keptkayas.tbank.prices.index', compact('prices'));
    }

    /**
     * Show the form for creating a new price.
     */
    public function create()
    {
        $price      = new KpTbankItemsPriceAndPoint();
        $items      = KpTbankItems::where('org_id_fk', Auth::user()->org_id_fk)->get();
        $units      = KpTbankUnits::where('org_id_fk', Auth::user()->org_id_fk)->get();
        $recorders  = Staff::whereHas('user', function ($q) {
            $q->where('org_id_fk', Auth::user()->org_id_fk);
        })->get();

        return view('keptkayas.tbank.prices.create', compact('price', 'items', 'units', 'recorders'));
    }

    /**
     * Store a newly created price in storage.
     */

    public function store(Request $request)
    {
        // 1. Validation
        $request->validate([
            // Validation สำหรับ Global Fields
            'recorder_id' => 'nullable|exists:users,id',
            'comment' => 'nullable|string|max:2000',
            'is_active' => 'nullable|boolean',

            // Validation สำหรับ Item Block (ใช้ Wildcard *)
            'items_data' => 'required|array|min:1',
            'items_data.*.kp_items_idfk' => 'required|exists:kp_tbank_items,id',
            'items_data.*.effective_date' => 'required|date',
            // end_date เป็น nullable เพราะอาจเป็น null เมื่อเลือก 'ตลอดไป'
            'items_data.*.end_date' => 'nullable|date|after_or_equal:items_data.*.effective_date',
            'items_data.*.is_forever_active' => 'nullable|boolean',

            // Validation สำหรับ หน่วยนับ (Price Tiers)
            'items_data.*.units_data' => 'required|array|min:1',
            'items_data.*.units_data.*.kp_units_idfk' => 'required|exists:kp_tbank_items_units,id',
            'items_data.*.units_data.*.price_for_member' => 'required|numeric|min:0',
            'items_data.*.units_data.*.price_from_dealer' => 'required|numeric|min:0',
            'items_data.*.units_data.*.point' => 'required|integer|min:0',
        ]);

        $itemsData = $request->input('items_data');

        // 2. วนลูปบันทึกข้อมูล
        foreach ($itemsData as $itemData) {

            // --- A. จัดการ Logic วันที่สิ้นสุด (ตลอดไป) ---
            $endDate = null;
            if (!isset($itemData['is_forever_active']) || $itemData['is_forever_active'] != 1) {
                // ถ้าไม่ได้เลือก 'ตลอดไป' ให้ใช้ค่า end_date ที่ส่งมา (ซึ่งอาจเป็น null ถ้าไม่ได้กรอก)
                $endDate = $itemData['end_date'];
            }


            $kp_units_idfkArr = KpTbankItemsPriceAndPoint::where('status', 'active')
                ->where('org_id_fk', Auth::user()->org_id_fk)
                ->where('kp_items_idfk', $itemData['kp_items_idfk'])
                ->get()->pluck('kp_units_idfk');


            foreach ($itemData['units_data'] as $unit) {

                if (in_array($unit['kp_units_idfk'], collect($kp_units_idfkArr)->toArray())) {
                    //ให้ inactive ตัวเก่า
                    KpTbankItemsPriceAndPoint::where('kp_items_idfk', $itemData['kp_items_idfk'])
                        ->where('kp_units_idfk', $unit['kp_units_idfk'])->update([
                            'status'        => 'inactive',
                            'updated_at'    => date('Y-m-d H:i:s'),
                        ]);
                }
                KpTbankItemsPriceAndPoint::create([
                    'kp_items_idfk'         =>  $itemData['kp_items_idfk'],
                    'price_from_dealer'     => $unit['price_from_dealer'],
                    'price_for_member'      => $unit['price_for_member'],
                    'point'                 => $unit['point'],
                    'type'                  => 'tbank',
                    'kp_units_idfk'         => $unit['kp_units_idfk'],
                    'status'                => 'active',
                    'deleted'               => '0',
                    'recorder_id'           => $request->get('recorder_id') ?? Auth::id(),
                    'effective_date'        => $itemData['effective_date'],
                    'org_id_fk'             => Auth::user()->org_id_fk,
                    'end_date'              => $endDate,
                    'created_at'            => date('Y-m-d H:i:s'),
                    'updated_at'            => date('Y-m-d H:i:s'),
                ]);
            }
        }
        // return 'ss';
        return redirect()->route('keptkayas.tbank.prices.index')
            ->with('success', 'บันทึกรายการกำหนดราคาหลายรายการเรียบร้อยแล้ว');
    }


    /**
     * Show the form for editing the specified price.
     */
    public function edit(KpTbankItemsPriceAndPoint $price)
    {
        $items = KpTbankItems::all();
        $units = KpTbankUnits::all();
        $recorders = User::all();
        return view('keptkayas.tbank.prices.edit', compact('price', 'items', 'units', 'recorders'));
    }

    /**
     * Update the specified price in storage.
     */
    public function update(Request $request, KpTbankItemsPriceAndPoint $price)
    {
        $validated = $request->validate([
            'kp_items_idfk' => 'required|exists:kp_recycle_items,id',
            'price_from_dealer' => 'required|numeric|min:0',
            'price_for_member' => 'required|numeric|min:0',
            'point' => 'nullable|integer|min:0',
            'type' => 'required|string|in:fixed,kg,unit', // e.g.,
            'kp_units_idfk' => 'required|exists:tbank_item_units,id',
            'effective_date' => 'required|date',
            'end_date' => 'nullable|date|after_or_equal:effective_date',
            'is_active' => 'boolean',
            'status' => 'required|in:active,inactive',
            'recorder_id' => 'nullable|exists:users,id',
        ]);

        DB::beginTransaction();
        try {
            // Logic to handle old active price is in the model's boot method
            $price->update(array_merge($validated, [
                'is_active' => $request->has('is_active'),
                'recorder_id' => $validated['recorder_id'] ?? Auth::id(),
            ]));

            DB::commit();
            return redirect()->route('keptkayas.tbank.prices.index')
                ->with('success', 'ราคารับซื้อถูกอัปเดตเรียบร้อยแล้ว');
        } catch (\Exception $e) {
            DB::rollBack();
            return back()->with('error', 'เกิดข้อผิดพลาดในการอัปเดตราคา: ' . $e->getMessage())->withInput();
        }
    }

    /**
     * Remove the specified price from storage.
     */
    public function destroy(KpTbankItemsPriceAndPoint $price)
    {
        // Add check if price is used in any transactions before deleting
        // ...

        $price->delete();
        return redirect()->route('keptkayas.tbank.prices.index')
            ->with('success', 'ราคารับซื้อถูกลบเรียบร้อยแล้ว');
    }

    public function export()
    {
        // ใช้ Org ID จาก Session ของ Super Admin หรือจาก Auth ปกติ
        $orgId = session('active_org_id') ?? Auth::user()->org_id_fk;

        $fileName = 'price_template_' . date('Ymd_His') . '.xlsx';

        return Excel::download(new PriceTemplateExport($orgId), $fileName);
    }

    public function import(Request $request)
    {
        $orgId = Auth::user()->org_id_fk;
        $import = new KpTbankPriceImport($orgId);

        try {
            Excel::import($import, $request->file('file'));

            if ($import->successCount > 0) {
                return back()->with('success', "นำเข้าข้อมูลสำเร็จ {$import->successCount} รายการ");
            } else {
                return back()->with('error', "ไม่มีข้อมูลถูกนำเข้า กรุณาตรวจสอบว่า Item ID และชื่อหน่วยนับตรงกับในระบบหรือไม่ (ดูรายละเอียดใน Log)");
            }
        } catch (\Exception $e) {
            return back()->with('error', "เกิดข้อผิดพลาดรุนแรง: " . $e->getMessage());
        }
    }

   public function bulkEdit()
{
    // Eager load 'prices' พร้อมเงื่อนไข status = 'active'
    $items = KpTbankItems::with(['prices' => function($query) {
        $query->where('status', 'active');
    }, 'unitBank', 'unitKiosk'])->orderBy('kp_itemsname', 'asc')->get();

    return view('keptkayas.tbank.prices.bulk_edit', compact('items'));
}

public function bulkUpdate(Request $request)
{
    $itemsData = $request->input('items', []);

    // ใช้ DB Transaction เพื่อป้องกันข้อมูลบันทึกไม่ครบหากเกิด Error
    return DB::transaction(function () use ($itemsData) {
        foreach ($itemsData as $id => $data) {
            $item = KpTbankItems::find($id);
            if (!$item) continue;

            // 1. อัปเดตสถานะการเปิด/ปิด ของตัวสินค้าขยะในตารางหลัก
            $item->update(['status' => $data['status']]);

            // 2. จัดการราคาฝั่ง Bank (ส่งค่า Dealer, Member, และ Point)
            $this->updatePriceRecord(
                $item,
                $item->unit_bank_idfk,
                $data['dealer_bank'],
                $data['member_bank'],
                $data['point_bank']
            );

            // 3. จัดการราคาฝั่ง Kiosk (ถ้าขยะชิ้นนี้รองรับ Kiosk)
            if ($item->unit_kiosk_idfk) {
                $this->updatePriceRecord(
                    $item,
                    $item->unit_kiosk_idfk,
                    $data['dealer_kiosk'],
                    $data['member_kiosk'],
                    $data['point_kiosk']
                );
            }
        }

        return redirect()->back()->with('success', 'บันทึกประวัติราคาและแต้มใหม่เรียบร้อยแล้ว');
    });
}

/**
 * ฟังก์ชันช่วยตรวจสอบและบันทึกราคาใหม่หากมีการเปลี่ยนแปลง
 */
private function updatePriceRecord($item, $unitId, $newDealerPrice, $newMemberPrice, $newPoint)
{
    // ค้นหาราคาปัจจุบันที่ยัง Active อยู่ของหน่วยนั้นๆ
    $current = KpTbankItemsPriceAndPoint::where('kp_items_idfk', $item->id)
                ->where('kp_units_idfk', $unitId)
                ->where('status', 'active')
                ->first();

    // เช็คว่าราคา Dealer, Member หรือ Point มีการเปลี่ยนแปลงหรือไม่
    $isChanged = !$current ||
                 (float)$current->price_from_dealer != (float)$newDealerPrice ||
                 (float)$current->price_for_member != (float)$newMemberPrice ||
                 (int)$current->point != (int)$newPoint;

    if ($isChanged) {
        // A. ปิดประวัติราคาเดิม (Update status เป็น inactive และลงวันที่สิ้นสุด)
        KpTbankItemsPriceAndPoint::where('kp_items_idfk', $item->id)
            ->where('kp_units_idfk', $unitId)
            ->where('status', 'active')
            ->update([
                'status' => 'inactive',
                'end_date' => now()->toDateString()
            ]);

        // B. สร้างประวัติราคาชุดใหม่ (Insert ใหม่เพื่อเก็บประวัติ)
        KpTbankItemsPriceAndPoint::create([
            'kp_items_idfk'     => $item->id,
            'price_from_dealer' => $newDealerPrice, // ราคาร้านรับซื้อ
            'price_for_member'  => $newMemberPrice,  // ราคารับซื้อจากสมาชิก
            'point'             => $newPoint,
            'kp_units_idfk'     => $unitId,
            'type'              => 'tbank',
            'status'            => 'active',
            'effective_date'    => now()->toDateString(),
            'recorder_id'       => Auth::id(),
            'org_id_fk'         => $item->org_id_fk
        ]);
    }
}
}
